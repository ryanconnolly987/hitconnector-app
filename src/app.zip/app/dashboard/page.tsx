import Link from "next/link"
import Image from "next/image"
import { CalendarDays, Clock, MapPin, Settings, Search, Calendar, Star } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarProvider,
  SidebarInset,
} from "@/components/ui/sidebar"

export default function DashboardPage() {
  // Mock data for the dashboard
  const user = {
    name: "Marcus Johnson",
    avatar: "/placeholder.svg?height=40&width=40",
  }

  const upcomingBookings = [
    {
      id: 1,
      studioName: "Soundwave Studios",
      studioImage: "/placeholder.svg?height=80&width=80",
      date: "May 15, 2025",
      time: "2:00 PM - 5:00 PM",
      location: "Los Angeles, CA",
      status: "confirmed",
    },
    {
      id: 2,
      studioName: "Beat Factory",
      studioImage: "/placeholder.svg?height=80&width=80",
      date: "May 22, 2025",
      time: "1:00 PM - 4:00 PM",
      location: "Atlanta, GA",
      status: "pending",
    },
  ]

  const pastVisits = [
    {
      id: 1,
      studioName: "Rhythm House",
      studioImage: "/placeholder.svg?height=80&width=80",
      date: "April 28, 2025",
      time: "3:00 PM - 6:00 PM",
      location: "New York, NY",
      rating: 5,
      review: "Amazing equipment and great sound engineer. Will definitely book again!",
    },
    {
      id: 2,
      studioName: "Flow Records",
      studioImage: "/placeholder.svg?height=80&width=80",
      date: "April 15, 2025",
      time: "2:00 PM - 5:00 PM",
      location: "Miami, FL",
      rating: 4,
      review: "",
    },
  ]

  return (
    <SidebarProvider>
      <div className="flex min-h-screen bg-muted/40">
        <DashboardSidebar />
        <SidebarInset>
          <div className="flex-1 space-y-6 p-6 md:p-8">
            <header className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h1 className="text-2xl font-bold tracking-tight">Welcome back, {user.name}!</h1>
                <p className="text-muted-foreground">
                  Manage your bookings and find the perfect studio for your next hit.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">
                  <CalendarDays className="mr-2 h-4 w-4" />
                  View Calendar
                </Button>
                <Button size="sm">
                  <Search className="mr-2 h-4 w-4" />
                  Find Studios
                </Button>
              </div>
            </header>

            <Tabs defaultValue="upcoming" className="space-y-4">
              <TabsList>
                <TabsTrigger value="upcoming">Upcoming Bookings</TabsTrigger>
                <TabsTrigger value="past">Past Visits</TabsTrigger>
              </TabsList>

              <TabsContent value="upcoming" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {upcomingBookings.map((booking) => (
                    <Card key={booking.id}>
                      <CardHeader className="flex flex-row items-center gap-4 pb-2">
                        <div className="h-16 w-16 overflow-hidden rounded-md">
                          <Image
                            src={booking.studioImage || "/placeholder.svg"}
                            alt={booking.studioName}
                            width={80}
                            height={80}
                            className="h-full w-full object-cover"
                          />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{booking.studioName}</CardTitle>
                          <Badge variant={booking.status === "confirmed" ? "default" : "outline"}>
                            {booking.status === "confirmed" ? "Confirmed" : "Pending"}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="pb-2">
                        <div className="grid gap-2">
                          <div className="flex items-center gap-2 text-sm">
                            <CalendarDays className="h-4 w-4 text-muted-foreground" />
                            <span>{booking.date}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span>{booking.time}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <MapPin className="h-4 w-4 text-muted-foreground" />
                            <span>{booking.location}</span>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Button variant="outline" className="w-full" asChild>
                          <Link href={`/bookings/${booking.id}`}>View Details</Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}

                  {upcomingBookings.length === 0 && (
                    <div className="col-span-full flex flex-col items-center justify-center rounded-lg border border-dashed p-8 text-center">
                      <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                        <Calendar className="h-6 w-6 text-muted-foreground" />
                      </div>
                      <h3 className="mt-4 text-lg font-semibold">No upcoming bookings</h3>
                      <p className="mb-4 mt-2 text-sm text-muted-foreground">
                        You don't have any upcoming studio sessions scheduled.
                      </p>
                      <Button asChild>
                        <Link href="/find-studios">Find Studios</Link>
                      </Button>
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="past" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {pastVisits.map((visit) => (
                    <Card key={visit.id}>
                      <CardHeader className="flex flex-row items-center gap-4 pb-2">
                        <div className="h-16 w-16 overflow-hidden rounded-md">
                          <Image
                            src={visit.studioImage || "/placeholder.svg"}
                            alt={visit.studioName}
                            width={80}
                            height={80}
                            className="h-full w-full object-cover"
                          />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{visit.studioName}</CardTitle>
                          <div className="flex items-center">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star
                                key={i}
                                className={`h-4 w-4 ${
                                  i < visit.rating ? "fill-yellow-500 text-yellow-500" : "text-muted-foreground"
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="pb-2">
                        <div className="grid gap-2">
                          <div className="flex items-center gap-2 text-sm">
                            <CalendarDays className="h-4 w-4 text-muted-foreground" />
                            <span>{visit.date}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span>{visit.time}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <MapPin className="h-4 w-4 text-muted-foreground" />
                            <span>{visit.location}</span>
                          </div>

                          {visit.review ? (
                            <div className="mt-2 text-sm">
                              <p className="italic">"{visit.review}"</p>
                            </div>
                          ) : (
                            <div className="mt-2 space-y-2">
                              <div className="flex items-center gap-1">
                                {Array.from({ length: 5 }).map((_, i) => (
                                  <button
                                    key={i}
                                    className="rounded-full p-0.5 hover:bg-muted focus:outline-none focus:ring-2 focus:ring-primary"
                                  >
                                    <Star className="h-5 w-5 text-muted-foreground hover:fill-yellow-500 hover:text-yellow-500" />
                                  </button>
                                ))}
                              </div>
                              <Textarea placeholder="Write your review here..." className="h-20 resize-none" />
                            </div>
                          )}
                        </div>
                      </CardContent>
                      <CardFooter>
                        {visit.review ? (
                          <Button variant="outline" className="w-full" asChild>
                            <Link href={`/bookings/${visit.id}`}>View Details</Link>
                          </Button>
                        ) : (
                          <Button className="w-full">Submit Review</Button>
                        )}
                      </CardFooter>
                    </Card>
                  ))}

                  {pastVisits.length === 0 && (
                    <div className="col-span-full flex flex-col items-center justify-center rounded-lg border border-dashed p-8 text-center">
                      <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                        <Calendar className="h-6 w-6 text-muted-foreground" />
                      </div>
                      <h3 className="mt-4 text-lg font-semibold">No past visits</h3>
                      <p className="mb-4 mt-2 text-sm text-muted-foreground">You haven't visited any studios yet.</p>
                      <Button asChild>
                        <Link href="/find-studios">Find Studios</Link>
                      </Button>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  )
}

function DashboardSidebar() {
  return (
    <Sidebar variant="inset" collapsible="icon">
      <SidebarHeader className="flex h-14 items-center border-b px-4">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <span className="text-xl font-bold">HitConnector</span>
        </Link>
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton asChild isActive>
              <Link href="/dashboard">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-4 w-4"
                >
                  <rect width="7" height="9" x="3" y="3" rx="1" />
                  <rect width="7" height="5" x="14" y="3" rx="1" />
                  <rect width="7" height="9" x="14" y="12" rx="1" />
                  <rect width="7" height="5" x="3" y="16" rx="1" />
                </svg>
                <span>Dashboard</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <Link href="/find-studios">
                <Search className="h-4 w-4" />
                <span>Find Studios</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <Link href="/bookings">
                <Calendar className="h-4 w-4" />
                <span>My Bookings</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <Link href="/settings">
                <Settings className="h-4 w-4" />
                <span>Account Settings</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="border-t p-4">
        <div className="flex items-center gap-4">
          <Avatar>
            <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Marcus Johnson" />
            <AvatarFallback>MJ</AvatarFallback>
          </Avatar>
          <div className="flex flex-col">
            <span className="text-sm font-medium">Marcus Johnson</span>
            <span className="text-xs text-muted-foreground">marcus@example.com</span>
          </div>
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}