"use client"

import { useState } from "react"
import Link from "next/link"
import { format, addDays, startOfWeek, eachDayOfInterval } from "date-fns"
import {
  CalendarDays,
  Clock,
  Settings,
  Upload,
  DollarSign,
  Users,
  Star,
  Check,
  X,
  ChevronLeft,
  ChevronRight,
  LayoutDashboard,
  BookOpen,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarProvider,
  SidebarInset,
} from "@/components/ui/sidebar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function StudioDashboardPage() {
  const [currentDate, setCurrentDate] = useState(new Date())

  // Mock data for the dashboard
  const studio = {
    name: "Soundwave Studios",
    avatar: "/placeholder.svg?height=40&width=40",
    email: "contact@soundwavestudios.com",
    rating: 4.8,
    reviewCount: 42,
  }

  // Generate week days for the calendar
  const startOfCurrentWeek = startOfWeek(currentDate, { weekStartsOn: 1 })
  const weekDays = eachDayOfInterval({
    start: startOfCurrentWeek,
    end: addDays(startOfCurrentWeek, 6),
  })

  // Mock bookings data
  const bookings = [
    {
      id: 1,
      artistName: "Marcus Johnson",
      artistImage: "/placeholder.svg?height=40&width=40",
      date: format(addDays(new Date(), 1), "yyyy-MM-dd"),
      startTime: "14:00",
      endTime: "17:00",
      roomName: "Studio A",
      status: "confirmed",
    },
    {
      id: 2,
      artistName: "Alicia Reynolds",
      artistImage: "/placeholder.svg?height=40&width=40",
      date: format(addDays(new Date(), 2), "yyyy-MM-dd"),
      startTime: "10:00",
      endTime: "13:00",
      roomName: "Studio B",
      status: "confirmed",
    },
    {
      id: 3,
      artistName: "DJ Maximus",
      artistImage: "/placeholder.svg?height=40&width=40",
      date: format(addDays(new Date(), 3), "yyyy-MM-dd"),
      startTime: "18:00",
      endTime: "22:00",
      roomName: "Studio A",
      status: "confirmed",
    },
  ]

  // Mock booking requests
  const bookingRequests = [
    {
      id: 1,
      artistName: "Lyrical Genius",
      artistImage: "/placeholder.svg?height=40&width=40",
      date: format(addDays(new Date(), 4), "MMM dd, yyyy"),
      time: "2:00 PM - 5:00 PM",
      roomName: "Studio A",
      message: "Looking to record my new single. Need a good sound engineer.",
    },
    {
      id: 2,
      artistName: "Beat Master",
      artistImage: "/placeholder.svg?height=40&width=40",
      date: format(addDays(new Date(), 5), "MMM dd, yyyy"),
      time: "6:00 PM - 9:00 PM",
      roomName: "Studio B",
      message: "Need the space for mixing and mastering a 5-track EP.",
    },
  ]

  // Function to navigate weeks
  const navigateWeek = (direction: "prev" | "next") => {
    const days = direction === "prev" ? -7 : 7
    setCurrentDate((prevDate) => addDays(prevDate, days))
  }

  // Function to get bookings for a specific day and time slot
  const getBookingsForSlot = (date: string, timeSlot: string) => {
    return bookings.filter(
      (booking) =>
        booking.date === date &&
        ((timeSlot === "morning" && booking.startTime >= "08:00" && booking.startTime < "12:00") ||
          (timeSlot === "afternoon" && booking.startTime >= "12:00" && booking.startTime < "17:00") ||
          (timeSlot === "evening" && booking.startTime >= "17:00" && booking.startTime <= "23:00")),
    )
  }

  return (
    <SidebarProvider>
      <div className="flex min-h-screen bg-muted/40">
        <StudioDashboardSidebar studio={studio} />
        <SidebarInset>
          <div className="flex-1 space-y-6 p-6 md:p-8">
            <header className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h1 className="text-2xl font-bold tracking-tight">Manage Your Studio</h1>
                <p className="text-muted-foreground">
                  Welcome back to {studio.name}. Manage your bookings and studio profile.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex items-center">
                  <div className="flex items-center mr-2">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${
                          i < Math.floor(studio.rating) ? "fill-yellow-500 text-yellow-500" : "text-muted-foreground"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm font-medium">{studio.rating}</span>
                  <span className="text-sm text-muted-foreground ml-1">({studio.reviewCount} reviews)</span>
                </div>
                <Button variant="outline" size="sm" asChild>
                  <Link href="/studio-profile">View Public Profile</Link>
                </Button>
              </div>
            </header>

            <div className="grid gap-6 md:grid-cols-3">
              <Card className="md:col-span-2">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <div>
                    <CardTitle>Weekly Schedule</CardTitle>
                    <CardDescription>Manage your studio bookings</CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="icon" onClick={() => navigateWeek("prev")}>
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <span className="text-sm">
                      {format(weekDays[0], "MMM d")} - {format(weekDays[6], "MMM d, yyyy")}
                    </span>
                    <Button variant="outline" size="icon" onClick={() => navigateWeek("next")}>
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                    <Select defaultValue="week">
                      <SelectTrigger className="w-[100px]">
                        <SelectValue placeholder="View" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="week">Week</SelectItem>
                        <SelectItem value="month">Month</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-8 gap-1">
                    <div className="p-2 text-center font-medium text-sm">Time</div>
                    {weekDays.map((day) => (
                      <div key={day.toString()} className="p-2 text-center font-medium text-sm">
                        <div>{format(day, "EEE")}</div>
                        <div
                          className={`text-xs ${format(day, "yyyy-MM-dd") === format(new Date(), "yyyy-MM-dd") ? "bg-primary text-primary-foreground rounded-full px-1" : ""}`}
                        >
                          {format(day, "d")}
                        </div>
                      </div>
                    ))}

                    {/* Morning time slot */}
                    <div className="p-2 text-xs text-muted-foreground">8AM - 12PM</div>
                    {weekDays.map((day) => {
                      const dayStr = format(day, "yyyy-MM-dd")
                      const dayBookings = getBookingsForSlot(dayStr, "morning")
                      return (
                        <div key={`morning-${dayStr}`} className="min-h-[60px] border rounded-md p-1 text-xs">
                          {dayBookings.map((booking) => (
                            <div key={booking.id} className="bg-primary/10 rounded p-1 mb-1 truncate">
                              <div className="font-medium">{booking.artistName}</div>
                              <div>
                                {booking.startTime} - {booking.endTime}
                              </div>
                            </div>
                          ))}
                        </div>
                      )
                    })}

                    {/* Afternoon time slot */}
                    <div className="p-2 text-xs text-muted-foreground">12PM - 5PM</div>
                    {weekDays.map((day) => {
                      const dayStr = format(day, "yyyy-MM-dd")
                      const dayBookings = getBookingsForSlot(dayStr, "afternoon")
                      return (
                        <div key={`afternoon-${dayStr}`} className="min-h-[60px] border rounded-md p-1 text-xs">
                          {dayBookings.map((booking) => (
                            <div key={booking.id} className="bg-primary/10 rounded p-1 mb-1 truncate">
                              <div className="font-medium">{booking.artistName}</div>
                              <div>
                                {booking.startTime} - {booking.endTime}
                              </div>
                            </div>
                          ))}
                        </div>
                      )
                    })}

                    {/* Evening time slot */}
                    <div className="p-2 text-xs text-muted-foreground">5PM - 11PM</div>
                    {weekDays.map((day) => {
                      const dayStr = format(day, "yyyy-MM-dd")
                      const dayBookings = getBookingsForSlot(dayStr, "evening")
                      return (
                        <div key={`evening-${dayStr}`} className="min-h-[60px] border rounded-md p-1 text-xs">
                          {dayBookings.map((booking) => (
                            <div key={booking.id} className="bg-primary/10 rounded p-1 mb-1 truncate">
                              <div className="font-medium">{booking.artistName}</div>
                              <div>
                                {booking.startTime} - {booking.endTime}
                              </div>
                            </div>
                          ))}
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>

              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Studio Management</CardTitle>
                    <CardDescription>Manage your studio details</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button variant="outline" className="w-full justify-start" asChild>
                      <Link href="/studio-dashboard/upload-images">
                        <Upload className="mr-2 h-4 w-4" />
                        Upload Images
                      </Link>
                    </Button>
                    <Button variant="outline" className="w-full justify-start" asChild>
                      <Link href="/studio-dashboard/pricing">
                        <DollarSign className="mr-2 h-4 w-4" />
                        Edit Pricing & Availability
                      </Link>
                    </Button>
                    <Button variant="outline" className="w-full justify-start" asChild>
                      <Link href="/studio-dashboard/staff">
                        <Users className="mr-2 h-4 w-4" />
                        Manage Studio Staff Bios
                      </Link>
                    </Button>
                    <Button variant="outline" className="w-full justify-start" asChild>
                      <Link href="/studio-dashboard/reviews">
                        <Star className="mr-2 h-4 w-4" />
                        View Reviews
                      </Link>
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Booking Requests</CardTitle>
                    <CardDescription>Pending requests from artists</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {bookingRequests.length > 0 ? (
                      bookingRequests.map((request) => (
                        <div key={request.id} className="border rounded-lg p-4 space-y-3">
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarImage src={request.artistImage || "/placeholder.svg"} alt={request.artistName} />
                              <AvatarFallback>{request.artistName.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">{request.artistName}</div>
                              <div className="text-sm text-muted-foreground">{request.roomName}</div>
                            </div>
                          </div>
                          <div className="space-y-1 text-sm">
                            <div className="flex items-center gap-2">
                              <CalendarDays className="h-4 w-4 text-muted-foreground" />
                              <span>{request.date}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4 text-muted-foreground" />
                              <span>{request.time}</span>
                            </div>
                          </div>
                          <div className="text-sm italic">"{request.message}"</div>
                          <div className="flex gap-2">
                            <Button size="sm" className="flex-1">
                              <Check className="mr-1 h-4 w-4" /> Confirm
                            </Button>
                            <Button variant="outline" size="sm" className="flex-1">
                              <X className="mr-1 h-4 w-4" /> Decline
                            </Button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="flex flex-col items-center justify-center py-8 text-center">
                        <CalendarDays className="h-10 w-10 text-muted-foreground mb-2" />
                        <h3 className="font-medium">No pending requests</h3>
                        <p className="text-sm text-muted-foreground">New booking requests will appear here</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>

            <Tabs defaultValue="upcoming" className="space-y-4">
              <TabsList>
                <TabsTrigger value="upcoming">Upcoming Bookings</TabsTrigger>
                <TabsTrigger value="past">Past Bookings</TabsTrigger>
              </TabsList>

              <TabsContent value="upcoming">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {bookings.map((booking) => (
                    <Card key={booking.id}>
                      <CardHeader className="flex flex-row items-center gap-4 pb-2">
                        <Avatar>
                          <AvatarImage src={booking.artistImage || "/placeholder.svg"} alt={booking.artistName} />
                          <AvatarFallback>{booking.artistName.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <CardTitle className="text-base">{booking.artistName}</CardTitle>
                          <Badge variant={booking.status === "confirmed" ? "default" : "outline"}>
                            {booking.status === "confirmed" ? "Confirmed" : "Pending"}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="pb-2">
                        <div className="grid gap-2">
                          <div className="flex items-center gap-2 text-sm">
                            <CalendarDays className="h-4 w-4 text-muted-foreground" />
                            <span>{format(new Date(booking.date), "MMM dd, yyyy")}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span>
                              {booking.startTime} - {booking.endTime}
                            </span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <span className="font-medium">{booking.roomName}</span>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Button variant="outline" className="w-full" asChild>
                          <Link href={`/studio-dashboard/bookings/${booking.id}`}>View Details</Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="past">
                <div className="rounded-lg border p-8 text-center">
                  <h3 className="text-lg font-medium">Past bookings will appear here</h3>
                  <p className="text-sm text-muted-foreground mt-1">View your booking history and artist reviews</p>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  )
}

function StudioDashboardSidebar({ studio }: { studio: { name: string; avatar: string; email: string } }) {
  return (
    <Sidebar variant="inset" collapsible="icon">
      <SidebarHeader className="flex h-14 items-center border-b px-4">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <span className="text-xl font-bold">HitConnector</span>
        </Link>
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton asChild isActive>
              <Link href="/studio-dashboard">
                <LayoutDashboard className="h-4 w-4" />
                <span>Dashboard</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <Link href="/studio-dashboard/profile">
                <Users className="h-4 w-4" />
                <span>My Studio Profile</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <Link href="/studio-dashboard/bookings">
                <BookOpen className="h-4 w-4" />
                <span>Bookings</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <Link href="/studio-dashboard/settings">
                <Settings className="h-4 w-4" />
                <span>Account Settings</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="border-t p-4">
        <div className="flex items-center gap-4">
          <Avatar>
            <AvatarImage src={studio.avatar || "/placeholder.svg"} alt={studio.name} />
            <AvatarFallback>{studio.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="flex flex-col">
            <span className="text-sm font-medium">{studio.name}</span>
            <span className="text-xs text-muted-foreground">{studio.email}</span>
          </div>
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}